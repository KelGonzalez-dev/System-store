export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#050403',
        noir: '#0b0907',
        onyx: '#14100b',
        gold: { DEFAULT: '#d4af6a', light: '#f1d9a0', deep: '#8a6a2e' },
        ivory: '#f6efe2',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        body: ['Montserrat', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        marquee: { from: { transform: 'translate3d(0,0,0)' }, to: { transform: 'translate3d(-50%,0,0)' } },
        floaty: { '0%,100%': { transform: 'translate3d(0,0,0)' }, '50%': { transform: 'translate3d(0,-14px,0)' } },
        spinSlow: { to: { transform: 'rotate(360deg)' } },
        spinRev: { to: { transform: 'rotate(-360deg)' } },
      },
      animation: {
        marquee: 'marquee 55s linear infinite',
        floaty: 'floaty 8s ease-in-out infinite',
        'spin-slow': 'spinSlow 90s linear infinite',
        'spin-rev': 'spinRev 140s linear infinite',
      },
    },
  },
  plugins: [],
};

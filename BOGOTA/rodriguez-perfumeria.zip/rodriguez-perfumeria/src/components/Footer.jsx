import { BRAND, CONTACT, LOGO } from '../data/content';
import { link } from '../router';
import { Icon } from './Icons';

export default function Footer() {
  return (
    <footer className="hairline border-t bg-ink">
      <div className="container-x flex flex-col items-center gap-8 py-14 text-center">
        <img src={LOGO} alt={BRAND.name} className="h-28 w-28" loading="lazy" draggable="false" />
        <p className="font-display text-2xl font-light italic text-gold">{BRAND.tagline}</p>
        <div className="flex items-center gap-4">
          <a href={CONTACT.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="hairline grid h-12 w-12 place-items-center rounded-full border transition-colors hover:border-gold hover:text-gold"><Icon name="instagram" /></a>
          <a {...link('#inicio')} aria-label="Volver arriba" className="hairline grid h-12 w-12 place-items-center rounded-full border transition-colors hover:border-gold hover:text-gold"><Icon name="arrowUp" /></a>
        </div>
        <p className="text-xs text-ivory/40">© {new Date().getFullYear()} {BRAND.name}. Todos los derechos reservados.</p>
      </div>
    </footer>
  );
}

import { useEffect, useRef, useState } from 'react';
import { LOGO } from '../data/content';

/* ======================================================================
   LOADER · "POLVO DE ORO"
   1) Una galaxia de partículas doradas gira en el vacío.
   2) Se contrae y cada partícula vuela, en curva, hasta un punto del logo.
   3) El logo real se enciende con ondas de luz.
   4) Salida: las partículas estallan y la pantalla se abre en dos.
   Un solo <canvas>, un solo requestAnimationFrame, DPR limitado.
   ====================================================================== */

const DURATION = 5600; // ms hasta que empieza la salida
const LEAVE = 1700;    // ms de animación de salida
const CONV0 = 1500;    // inicio de la convergencia
const CDUR = 1500;     // duración de vuelo de cada partícula
const LINES = ['Destilando esencias', 'Mezclando notas', 'Dando forma'];
const TONES = ['#f6e3b0', '#d4af6a', '#a87d36'];
const BUCKET_ALPHA = [0.35, 0.65, 1];

const clamp = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const easeIO = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

function sampleLogo(img, S, N, cx, cy) {
  const R = 200;
  const c = document.createElement('canvas');
  c.width = c.height = R;
  const g = c.getContext('2d', { willReadFrequently: true });
  if (img && img.naturalWidth) g.drawImage(img, 0, 0, R, R);
  else {
    g.fillStyle = '#fff';
    g.font = `600 ${R * 0.7}px Georgia, serif`;
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('R', R / 2, R / 2);
  }
  const d = g.getImageData(0, 0, R, R).data;
  const pts = [];
  for (let y = 0; y < R; y++) for (let x = 0; x < R; x++) if (d[(y * R + x) * 4 + 3] > 110) pts.push(x, y);
  const n = pts.length / 2;
  const TX = new Float32Array(N);
  const TY = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    if (n) {
      const k = ((Math.random() * n) | 0) * 2;
      TX[i] = cx + ((pts[k] + Math.random()) / R - 0.5) * S;
      TY[i] = cy + ((pts[k + 1] + Math.random()) / R - 0.5) * S;
    } else {
      const a = (i / N) * 6.283;
      TX[i] = cx + Math.cos(a) * S * 0.4;
      TY[i] = cy + Math.sin(a) * S * 0.4;
    }
  }
  return { TX, TY };
}

export default function Loader({ onLeave }) {
  const [phase, setPhase] = useState('play');
  const cv = useRef(null);
  const counter = useRef(null);
  const skip = useRef(false);

  useEffect(() => {
    const root = document.documentElement;
    root.style.overflow = 'hidden';
    window.scrollTo(0, 0);

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const w = window.innerWidth;
    const h = window.innerHeight;
    const mobile = w < 768;
    const N = reduce ? 0 : mobile ? 1500 : 2800;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const cx = w / 2;
    const cy = h / 2;
    const S = Math.min(w * 0.78, h * 0.52, 440);
    const maxR = Math.min(Math.max(w, h) * 0.5, 560);

    let ctx = null;
    if (!reduce && cv.current) {
      cv.current.width = Math.round(w * dpr);
      cv.current.height = Math.round(h * dpr);
      ctx = cv.current.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    // Estado de partículas (typed arrays = cero basura por frame)
    const X = new Float32Array(N), Y = new Float32Array(N);
    const R0 = new Float32Array(N), TH = new Float32Array(N), OM = new Float32Array(N);
    const DL = new Float32Array(N), CU = new Float32Array(N), SZ = new Float32Array(N);
    const LX = new Float32Array(N), LY = new Float32Array(N), DX = new Float32Array(N), DY = new Float32Array(N), SP = new Float32Array(N);
    let TX = new Float32Array(N).fill(cx), TY = new Float32Array(N).fill(cy);
    const groups = Array.from({ length: 9 }, () => []);
    for (let i = 0; i < N; i++) {
      const k = Math.random();
      R0[i] = Math.pow(Math.random(), 0.62) * maxR + 6;
      TH[i] = (i % 3) * 2.094 + (R0[i] / maxR) * 5.2 + (Math.random() - 0.5) * 0.5;
      OM[i] = 0.22 / (0.3 + R0[i] / maxR);
      DL[i] = (1 - R0[i] / maxR) * 520 + Math.random() * 480;
      CU[i] = (Math.random() - 0.5) * 200;
      SZ[i] = (mobile ? 1.1 : 1.4) + Math.random() * 1.5;
      SP[i] = 250 + Math.random() * 750;
      groups[Math.min(2, (k * 3) | 0) * 3 + Math.min(2, (Math.random() * 3) | 0)].push(i);
    }

    const img = new Image();
    img.onload = img.onerror = () => {
      if (!reduce) ({ TX, TY } = sampleLogo(img, S, N, cx, cy));
    };
    img.src = LOGO;

    const t0 = performance.now();
    let leaving = false, leaveT = 0, leaveAt = reduce ? 1500 : DURATION, raf = 0, dead = false;

    const loop = (now) => {
      if (dead) return;
      const t = now - t0;
      if (skip.current && !leaving) leaveAt = Math.min(leaveAt, t);
      if (counter.current) counter.current.textContent = String(skip.current ? 100 : Math.min(100, Math.round((t / DURATION) * 100))).padStart(2, '0');

      if (!leaving && t >= leaveAt) {
        leaving = true;
        leaveT = t;
        for (let i = 0; i < N; i++) {
          LX[i] = X[i]; LY[i] = Y[i];
          const dx = X[i] - cx + (Math.random() - 0.5) * 30, dy = Y[i] - cy + (Math.random() - 0.5) * 30;
          const len = Math.hypot(dx, dy) || 1;
          DX[i] = dx / len; DY[i] = dy / len;
        }
        setPhase('leaving');
        onLeave?.();
      }
      if (leaving && t - leaveT > LEAVE) { setPhase('gone'); return; }

      if (ctx) {
        const lt = leaving ? (t - leaveT) / 1000 : 0;
        for (let i = 0; i < N; i++) {
          let x, y;
          if (leaving) {
            x = LX[i] + DX[i] * SP[i] * lt;
            y = LY[i] + DY[i] * SP[i] * lt;
          } else {
            const th = TH[i] + (OM[i] * t) / 1000;
            const sx = cx + Math.cos(th) * R0[i];
            const sy = cy + Math.sin(th) * R0[i] * 0.52;
            const p = clamp((t - CONV0 - DL[i]) / CDUR);
            if (p <= 0) { x = sx; y = sy; }
            else {
              const e = easeIO(p);
              const dx = TX[i] - sx, dy = TY[i] - sy;
              const len = Math.hypot(dx, dy) || 1;
              const curl = Math.sin(Math.PI * p) * CU[i];
              x = sx + dx * e - (dy / len) * curl;
              y = sy + dy * e + (dx / len) * curl;
              if (p >= 1) { x += Math.sin(t / 420 + i) * 0.5; y += Math.cos(t / 510 + i) * 0.5; }
            }
          }
          X[i] = x; Y[i] = y;
        }

        if (leaving) ctx.clearRect(0, 0, w, h);
        else {
          ctx.globalCompositeOperation = 'source-over';
          ctx.fillStyle = t > CONV0 + CDUR ? 'rgba(5,4,3,.55)' : 'rgba(5,4,3,.26)';
          ctx.fillRect(0, 0, w, h);
        }
        ctx.globalCompositeOperation = 'lighter';
        const fade = leaving ? Math.max(0, 1 - lt / 0.9) : clamp(t / 900);
        for (let g = 0; g < 9; g++) {
          ctx.globalAlpha = BUCKET_ALPHA[g % 3] * fade * (0.85 + 0.15 * Math.sin(t / 260 + g));
          ctx.fillStyle = TONES[(g / 3) | 0];
          const arr = groups[g];
          for (let j = 0; j < arr.length; j++) {
            const i = arr[j], s = SZ[i];
            ctx.fillRect(X[i] - s / 2, Y[i] - s / 2, s, s);
          }
        }
        ctx.globalAlpha = 1;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      dead = true;
      cancelAnimationFrame(raf);
      root.style.overflow = '';
    };
  }, [onLeave]);

  if (phase === 'gone') return null;

  return (
    <div className={`ld-root ${phase === 'leaving' ? 'ld-leaving' : ''}`} role="status" aria-live="polite" aria-label="Rodriguez Perfumería">
      <div className="ld-half ld-l" />
      <div className="ld-half ld-r" />
      <div className="ld-seam" />
      <canvas ref={cv} className="absolute inset-0 h-full w-full" />
      <div className="ld-vignette" />

      <div className="ld-logo pointer-events-none absolute inset-0 grid place-items-center">
        <div className="relative aspect-square w-[min(78vw,52svh,440px)]">
          <div className="ld-aura" />
          <span className="ld-shock" style={{ '--at': '4s' }} />
          <span className="ld-shock" style={{ '--at': '4.3s' }} />
          <img src={LOGO} alt="" className="ld-logo-img relative h-full w-full object-contain" draggable="false" />
        </div>
      </div>

      <div className="ld-ui absolute inset-x-0 bottom-0 flex flex-col items-center gap-5 px-6 pb-10 sm:pb-14">
        <div className="relative h-6 w-full max-w-xs text-center font-body text-[11px] font-light uppercase tracking-[.42em] text-ivory/70">
          {LINES.map((line, i) => (
            <span key={line} className="ld-line" style={{ '--l': `${0.3 + i * 1.3}s` }}>{line}</span>
          ))}
          <span className="ld-welcome gold-text absolute inset-0 flex items-center justify-center">Bienvenido</span>
        </div>
        <div className="flex items-baseline gap-2 font-display font-light text-gold/80">
          <span ref={counter} className="text-5xl tabular-nums tracking-widest">00</span>
          <span className="font-body text-xs tracking-[.3em]">/ 100</span>
        </div>
      </div>

      <button
        type="button"
        onClick={() => { skip.current = true; }}
        className="ld-ui absolute bottom-5 right-5 z-10 font-body text-[10px] font-medium uppercase tracking-[.3em] text-ivory/40 transition-colors hover:text-gold sm:bottom-8 sm:right-8"
      >
        Saltar
      </button>
    </div>
  );
}

import { STATS } from '../data/content';
import Reveal from '../components/Reveal';
import CountUp from '../components/CountUp';

export default function Stats() {
  return (
    <section className="hairline border-y bg-noir py-14 sm:py-20">
      <div className="container-x grid grid-cols-3 gap-4">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 120} className="px-1 text-center sm:px-2">
            <p className="gold-text font-display text-5xl font-light sm:text-8xl"><CountUp value={s.value} prefix={s.prefix} suffix={s.suffix} /></p>
            <p className="mt-2 font-body text-[10px] font-medium uppercase tracking-[.28em] text-ivory/55 sm:mt-3 sm:text-[11px]">{s.label}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

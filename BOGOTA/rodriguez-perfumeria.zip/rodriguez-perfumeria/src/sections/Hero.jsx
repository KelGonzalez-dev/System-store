import { useRef } from 'react';
import { useTilt } from '../hooks/useTilt';
import { link } from '../router';
import { waLink } from '../data/content';
import Bottle from '../components/Bottle';
import GoldDust from '../components/GoldDust';
import { Icon } from '../components/Icons';

const Item = ({ d, className = '', children }) => (
  <div className={`hero-item ${className}`} style={{ '--d': `${d}ms` }}>{children}</div>
);

const CHIPS = [
  { t: 'Oud', cls: 'left-[-2%] top-[18%]', d: '0s' },
  { t: 'Ámbar', cls: 'right-[-4%] top-[44%]', d: '-2.5s' },
  { t: 'Vainilla', cls: 'left-[4%] bottom-[14%]', d: '-5s' },
];

export default function Hero() {
  const stage = useRef(null);
  useTilt(stage, 10);

  return (
    <section id="inicio" className="grain relative isolate overflow-hidden bg-ink">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0" style={{ background: 'radial-gradient(55% 55% at 72% 46%, rgba(212,175,106,.22), transparent 70%), radial-gradient(40% 40% at 8% 92%, rgba(138,106,46,.2), transparent 70%)' }} />
        <GoldDust count={window.innerWidth < 768 ? 28 : 70} className="absolute inset-0 h-full w-full" />
      </div>

      <div className="container-x grid min-h-[100svh] items-center gap-4 pb-24 pt-24 md:grid-cols-12 md:gap-10 md:pb-28 md:pt-28">
        <div className="md:col-span-7">
          <Item d={250}><p className="eyebrow">Perfumería de autor</p></Item>
          <Item d={450}>
            <h1 className="h-display mt-5 text-[clamp(3.4rem,9.4vw,8.6rem)]">
              <span className="block">Tu esencia,</span>
              <span className="gold-shine block pb-2 font-light italic">tu firma.</span>
            </h1>
          </Item>
          <Item d={700}><p className="mt-6 max-w-md text-base leading-relaxed text-ivory/65 sm:text-lg">Originales, árabes y de nicho. Fragancias que hablan antes de que tú lo hagas.</p></Item>
          <Item d={900} className="mt-9 flex flex-wrap gap-4">
            <a {...link('#coleccion')} className="btn btn-gold">Ver colección<Icon name="arrow" className="h-4 w-4" /></a>
            <a href={waLink('Hola Rodriguez Perfumería, quiero asesoría para elegir mi perfume.')} target="_blank" rel="noopener noreferrer" className="btn btn-line">Pedir asesoría</a>
          </Item>
        </div>

        <div className="order-first md:order-none md:col-span-5">
          <Item d={800}>
            <div ref={stage} className="tilt relative mx-auto aspect-square w-[min(58vw,26rem)]">
              <svg viewBox="0 0 400 400" className="animate-spin-slow absolute inset-0 h-full w-full" fill="none" aria-hidden="true">
                <circle cx="200" cy="200" r="192" stroke="#d4af6a" strokeOpacity=".45" strokeDasharray="1 9" strokeLinecap="round" strokeWidth="2" />
                <circle cx="200" cy="8" r="4" fill="#f1d9a0" />
                <circle cx="392" cy="200" r="2.5" fill="#d4af6a" />
              </svg>
              <svg viewBox="0 0 400 400" className="animate-spin-rev absolute inset-0 h-full w-full" fill="none" aria-hidden="true">
                <circle cx="200" cy="200" r="160" stroke="#d4af6a" strokeOpacity=".22" />
                <circle cx="40" cy="200" r="3" fill="#d4af6a" />
              </svg>
              <div className="absolute inset-[10%] rounded-full" style={{ background: 'radial-gradient(circle, rgba(212,175,106,.28), transparent 68%)' }} />
              <div className="animate-floaty tilt-pop absolute inset-[12%]">
                <Bottle shape="classic" liquid="#b9772a" className="h-full w-full drop-shadow-[0_30px_40px_rgba(0,0,0,.55)]" />
              </div>
              {CHIPS.map((c) => (
                <span key={c.t} className={`animate-floaty tilt-pop absolute hidden rounded-full border border-gold/40 bg-ink/70 px-4 py-1.5 font-body text-[10px] font-medium uppercase tracking-[.28em] text-gold-light sm:block ${c.cls}`} style={{ animationDelay: c.d }}>
                  {c.t}
                </span>
              ))}
            </div>
          </Item>
        </div>
      </div>

      <div className="hero-item absolute inset-x-0 bottom-7 hidden flex-col items-center gap-3 md:flex" style={{ '--d': '1500ms' }}>
        <span className="font-body text-[10px] font-light uppercase tracking-[.4em] text-ivory/50">Desliza</span>
        <span className="relative h-12 w-px overflow-hidden bg-ivory/15">
          <span className="absolute inset-x-0 top-0 h-1/2 bg-gold" style={{ animation: 'scrollHint 2s cubic-bezier(.6,0,.3,1) infinite' }} />
        </span>
      </div>
    </section>
  );
}

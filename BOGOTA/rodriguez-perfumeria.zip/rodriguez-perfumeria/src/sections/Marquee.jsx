import { MARQUEE } from '../data/content';

export default function Marquee() {
  return (
    <div className="hairline overflow-hidden border-y bg-noir py-5" aria-hidden="true">
      <div className="animate-marquee flex w-max will-change-transform">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center gap-10 pr-10">
            {MARQUEE.map((w, i) => (
              <span key={w} className="flex items-center gap-10 font-display text-4xl font-light uppercase tracking-[.16em] sm:text-5xl">
                <span className={i % 2 ? 'outline-text' : 'text-ivory/80'}>{w}</span>
                <span className="h-1.5 w-1.5 rotate-45 bg-gold" style={{ boxShadow: '0 0 10px #d4af6a' }} />
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

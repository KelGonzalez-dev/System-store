# Rodriguez Perfumería · sitio web (demo)

React + Vite + Tailwind. Sin backend.

    npm install
    npm start        # desarrollo
    npm run build    # producción (carpeta build/)

## Qué editar

- **Todo el contenido** (WhatsApp, Instagram, productos, precios, notas, asesor, números): `src/data/content.js`
  - `CONTACT.whatsapp` → poner el número real (57 + número, sin espacios).
  - Los productos son de ejemplo. Para usar fotos reales agrega `img: 'foto.jpg'` al producto
    (guarda la foto en `public/`). Sin `img` se muestra el frasco ilustrado.
- Logo y favicon: `public/logo.webp`, `public/favicon.png` (usar un logo de mayor resolución si se tiene).
- Duración del loader: `DURATION` en `src/loader/Loader.jsx` (ms).
- Colores y fuentes: `tailwind.config.js` + `index.html` (Google Fonts).

## Rendimiento

- Loader en un solo `<canvas>` con un solo `requestAnimationFrame` (se detiene al terminar).
- Un único listener de scroll para todo el sitio (`hooks/scrollBus.js`).
- Polvo de oro y animaciones se pausan fuera de pantalla / pestaña oculta.
- El catálogo se carga bajo demanda (code-splitting).
- Respeta `prefers-reduced-motion` y desactiva tilt en pantallas táctiles.
